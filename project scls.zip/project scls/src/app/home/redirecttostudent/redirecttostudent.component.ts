import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redirecttostudent',
  templateUrl: './redirecttostudent.component.html',
  styleUrls: ['./redirecttostudent.component.css']
})
export class RedirecttostudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
