import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redirecttofaculty',
  templateUrl: './redirecttofaculty.component.html',
  styleUrls: ['./redirecttofaculty.component.css']
})
export class RedirecttofacultyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
