import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerdashboard',
  templateUrl: './registerdashboard.component.html',
  styleUrls: ['./registerdashboard.component.css']
})
export class RegisterdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
